---
title: Templates
---

# Templates

<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 1rem;
">
  <div>
    <h2 id="onyx"><a href="#onyx" class="header-anchor">#</a> Onyx</h2>
    <img src="./images/Onyx.png" />
  </div>
  <div>
    <h2 id="pikachu"><a href="#pikachu" class="header-anchor">#</a> Pikachu</h2>
    <img src="./images/Pikachu.png" />
  </div>
  <div>
    <h2 id="gengar"><a href="#gengar" class="header-anchor">#</a> Gengar</h2>
    <img src="./images/Gengar.png" />
  </div>
  <div>
    <h2 id="castform"><a href="#castform" class="header-anchor">#</a> Castform</h2>
    <img src="./images/Castform.png" />
  </div>
  <div>
    <h2 id="glalie"><a href="#glalie" class="header-anchor">#</a> Glalie</h2>
    <img src="./images/Glalie.png" />
  </div>
  <div>
    <h2 id="celebi"><a href="#celebi" class="header-anchor">#</a> Celebi</h2>
    <img src="./images/Celebi.png" />
  </div>
</div>
