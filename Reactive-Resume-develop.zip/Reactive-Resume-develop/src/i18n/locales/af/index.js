import app from './app';
import leftSidebar from './leftSidebar';
import rightSidebar from './rightSidebar';

export default {
  app,
  leftSidebar,
  rightSidebar,
};
