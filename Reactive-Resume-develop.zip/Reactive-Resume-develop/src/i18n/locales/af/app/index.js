import app from './app.json';

export default app;
