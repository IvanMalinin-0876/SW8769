import af from './af';
import ar from './ar';
import as from './as';
import ca from './ca';
import cs from './cs';
import da from './da';
import de from './de';
import el from './el';
import en from './en';
import es from './es';
import fi from './fi';
import fr from './fr';
import he from './he';
import hi from './hi';
import hu from './hu';
import it from './it';
import ja from './ja';
import kn from './kn';
import ko from './ko';
import ml from './ml';
import mr from './mr';
import nl from './nl';
import no from './no';
import pa from './pa';
import pl from './pl';
import pt from './pt';
import ro from './ro';
import ru from './ru';
import sv from './sv';
import ta from './ta';
import tr from './tr';
import uk from './uk';
import vi from './vi';
import zh from './zh';

export default {
  af,
  ar,
  as,
  ca,
  cs,
  da,
  de,
  el,
  en,
  es,
  fi,
  fr,
  he,
  hi,
  hu,
  it,
  ja,
  kn,
  ko,
  ml,
  mr,
  nl,
  no,
  pa,
  pl,
  pt,
  ro,
  ru,
  sv,
  ta,
  tr,
  uk,
  vi,
  zh,
};
